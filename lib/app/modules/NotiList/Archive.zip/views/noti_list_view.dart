import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../../../../flutter_flow/flutter_flow_icon_button.dart';
import '../../../../flutter_flow/flutter_flow_theme_new.dart';
import '../controllers/noti_list_controller.dart';

class NotiListView extends GetView<NotiListController> {
  const NotiListView({super.key});

  static const List<_NotificationItem> _allNotifications = [
    _NotificationItem(
      dateLabel: '09 กุมภาพันธ์ 2026',
      category: _NotificationCategory.task,
      title: 'นายสุขภาพดี จิตแจ่มใส',
      subtitle: 'อายุ 48 ปี 6 ด. 13 ว.',
      time: '12:30 น.',
      unread: true,
      avatarBackgroundColor: Color(0xFF73BDF6),
      avatarIcon: Icons.person_rounded,
      badgeColor: Color(0xFFFF8A00),
      badgeIcon: Icons.add_rounded,
    ),
    _NotificationItem(
      dateLabel: '09 กุมภาพันธ์ 2026',
      category: _NotificationCategory.task,
      title: 'นางรัตนา ศรีสุข',
      subtitle: 'อายุ 48 ปี 6 ด. 13 ว.',
      time: '12:30 น.',
      unread: false,
      avatarBackgroundColor: Color(0xFF8ACBFF),
      avatarIcon: Icons.person_rounded,
      badgeColor: Color(0xFFFF8A00),
      badgeIcon: Icons.add_rounded,
    ),
    _NotificationItem(
      dateLabel: '09 กุมภาพันธ์ 2026',
      category: _NotificationCategory.news,
      title: '5 ท่าบริหาร "ข้อเข่าเสื่อม" ทำง่าย แค่วันละ 10 นาที!',
      subtitle: 'ข่าวสาร',
      time: '12:30 น.',
      unread: true,
      avatarAssetPath: 'assets/images/profile.png',
      badgeColor: Color(0xFF329BFF),
      badgeIcon: Icons.description_rounded,
    ),
  ];

  List<_NotificationSectionData> _sectionsForTab(int tabIndex) {
    final items = switch (tabIndex) {
      1 =>
        _allNotifications
            .where((item) => item.category == _NotificationCategory.task)
            .toList(),
      2 =>
        _allNotifications
            .where((item) => item.category == _NotificationCategory.news)
            .toList(),
      _ => _allNotifications,
    };

    final sections = <String, List<_NotificationItem>>{};
    for (final item in items) {
      sections
          .putIfAbsent(item.dateLabel, () => <_NotificationItem>[])
          .add(item);
    }

    return sections.entries
        .map(
          (entry) => _NotificationSectionData(
            dateLabel: entry.key,
            items: entry.value,
          ),
        )
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowThemeNew.of(context);
    final tabController = controller.tabBarController;

    if (tabController == null) {
      return const SizedBox.shrink();
    }

    return Scaffold(
      key: controller.scaffoldKey,
      backgroundColor: theme.primary,
      appBar: AppBar(
        backgroundColor: theme.primary,
        automaticallyImplyLeading: false,
        leading: FlutterFlowIconButton(
          borderColor: Colors.transparent,
          borderRadius: 30.0,
          borderWidth: 1.0,
          buttonSize: 54.0,
          icon: const Icon(
            Icons.keyboard_arrow_left_rounded,
            color: Colors.white,
            size: 28.0,
          ),
          onPressed: () async {
            Get.back();
          },
        ),
        title: Text(
          'แจ้งเตือน',
          textAlign: TextAlign.center,
          style: theme.headlineSmall.override(
            fontFamily: theme.headlineSmallFamily,
            color: theme.secondaryBackground,
            fontSize: 22.0,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.0,
            useGoogleFonts: !theme.headlineSmallIsCustom,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 12.0, 8.0),
            child: Image.asset(
              'assets/images/noti.png',
              width: 48.0,
              height: 48.0,
              fit: BoxFit.contain,
            ),
          ),
        ],
        centerTitle: true,
        elevation: 0.0,
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          color: theme.primaryBackground,
          boxShadow: const [
            BoxShadow(
              blurRadius: 12.0,
              color: Color(0x1A000000),
              offset: Offset(0.0, -2.0),
            ),
          ],
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(30.0),
            topRight: Radius.circular(30.0),
          ),
        ),
        child: SafeArea(
          top: false,
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 560.0),
              child: Column(
                children: [
                  const SizedBox(height: 16.0),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: _NotificationTabs(controller: tabController),
                  ),
                  Expanded(
                    child: TabBarView(
                      controller: tabController,
                      children: List.generate(
                        3,
                        (index) => _NotificationTabContent(
                          sections: _sectionsForTab(index),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NotificationTabs extends StatelessWidget {
  const _NotificationTabs({required this.controller});

  final TabController controller;

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowThemeNew.of(context);

    return Container(
      height: 56.0,
      decoration: BoxDecoration(
        color: const Color(0xFFDCE4F2),
        borderRadius: BorderRadius.circular(30.0),
      ),
      child: TabBar(
        controller: controller,
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelPadding: EdgeInsets.zero,
        splashBorderRadius: BorderRadius.circular(30.0),
        indicator: BoxDecoration(
          color: theme.primary,
          borderRadius: BorderRadius.circular(30.0),
        ),
        labelColor: Colors.white,
        unselectedLabelColor: theme.secondaryText,
        labelStyle: theme.titleMedium.override(
          fontFamily: theme.titleMediumFamily,
          fontSize: 18.0,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.0,
          useGoogleFonts: !theme.titleMediumIsCustom,
        ),
        unselectedLabelStyle: theme.titleMedium.override(
          fontFamily: theme.titleMediumFamily,
          fontSize: 18.0,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.0,
          useGoogleFonts: !theme.titleMediumIsCustom,
        ),
        tabs: const [
          Tab(text: 'ทั้งหมด'),
          Tab(text: 'งานใหม่'),
          Tab(text: 'ข่าวสาร'),
        ],
      ),
    );
  }
}

class _NotificationTabContent extends StatelessWidget {
  const _NotificationTabContent({required this.sections});

  final List<_NotificationSectionData> sections;

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowThemeNew.of(context);

    if (sections.isEmpty) {
      return Center(
        child: Text(
          'ไม่มีรายการแจ้งเตือน',
          style: theme.bodyMedium.override(
            fontFamily: theme.bodyMediumFamily,
            color: theme.secondaryText,
            letterSpacing: 0.0,
            useGoogleFonts: !theme.bodyMediumIsCustom,
          ),
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16.0, 20.0, 16.0, 28.0),
      physics: const BouncingScrollPhysics(),
      itemCount: sections.length,
      separatorBuilder: (_, __) => const SizedBox(height: 18.0),
      itemBuilder: (context, index) {
        final section = sections[index];
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              section.dateLabel,
              style: theme.headlineSmall.override(
                fontFamily: theme.headlineSmallFamily,
                fontSize: 24.0,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.0,
                useGoogleFonts: !theme.headlineSmallIsCustom,
              ),
            ),
            const SizedBox(height: 12.0),
            _NotificationCard(items: section.items),
          ],
        );
      },
    );
  }
}

class _NotificationCard extends StatelessWidget {
  const _NotificationCard({required this.items});

  final List<_NotificationItem> items;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28.0),
        boxShadow: const [
          BoxShadow(
            blurRadius: 18.0,
            color: Color(0x14000000),
            offset: Offset(0.0, 6.0),
          ),
        ],
      ),
      child: Column(
        children: List.generate(items.length, (index) {
          final isLast = index == items.length - 1;
          return Column(
            children: [
              _NotificationRow(item: items[index]),
              if (!isLast)
                const Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(96.0, 0.0, 24.0, 0.0),
                  child: Divider(
                    height: 1.0,
                    thickness: 1.0,
                    color: Color(0xFFE4EBF4),
                  ),
                ),
            ],
          );
        }),
      ),
    );
  }
}

class _NotificationRow extends StatelessWidget {
  const _NotificationRow({required this.item});

  final _NotificationItem item;

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowThemeNew.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(22.0, 18.0, 22.0, 18.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _NotificationAvatar(item: item),
          const SizedBox(width: 14.0),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 4.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    maxLines: item.category == _NotificationCategory.news
                        ? 2
                        : 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.titleLarge.override(
                      fontFamily: theme.titleLargeFamily,
                      fontSize: 18.0,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.0,
                      useGoogleFonts: !theme.titleLargeIsCustom,
                    ),
                  ),
                  const SizedBox(height: 4.0),
                  Text(
                    item.subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.bodyMedium.override(
                      fontFamily: theme.bodyMediumFamily,
                      color: theme.secondaryText,
                      letterSpacing: 0.0,
                      useGoogleFonts: !theme.bodyMediumIsCustom,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 12.0),
          SizedBox(
            width: 76.0,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  item.time,
                  style: theme.bodyMedium.override(
                    fontFamily: theme.bodyMediumFamily,
                    color: theme.secondaryText,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0.0,
                    useGoogleFonts: !theme.bodyMediumIsCustom,
                  ),
                ),
                const SizedBox(height: 18.0),
                SizedBox(
                  height: 16.0,
                  child: item.unread
                      ? Container(
                          width: 16.0,
                          height: 16.0,
                          decoration: const BoxDecoration(
                            color: Color(0xFFFF4B3E),
                            shape: BoxShape.circle,
                          ),
                        )
                      : const SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _NotificationAvatar extends StatelessWidget {
  const _NotificationAvatar({required this.item});

  final _NotificationItem item;

  @override
  Widget build(BuildContext context) {
    final avatar = Container(
      width: 56.0,
      height: 56.0,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: item.avatarAssetPath == null
            ? LinearGradient(
                colors: [
                  item.avatarBackgroundColor!.withValues(alpha: 0.86),
                  item.avatarBackgroundColor!,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : null,
        image: item.avatarAssetPath != null
            ? DecorationImage(
                image: AssetImage(item.avatarAssetPath!),
                fit: BoxFit.cover,
              )
            : null,
        color: item.avatarAssetPath == null ? item.avatarBackgroundColor : null,
      ),
      child: item.avatarAssetPath == null
          ? Icon(item.avatarIcon, color: Colors.white, size: 30.0)
          : null,
    );

    return SizedBox(
      width: 62.0,
      height: 62.0,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned.fill(child: avatar),
          Positioned(
            right: -2.0,
            bottom: -2.0,
            child: Container(
              width: 24.0,
              height: 24.0,
              decoration: BoxDecoration(
                color: item.badgeColor,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2.5),
              ),
              child: Icon(item.badgeIcon, color: Colors.white, size: 14.0),
            ),
          ),
        ],
      ),
    );
  }
}

enum _NotificationCategory { task, news }

class _NotificationItem {
  const _NotificationItem({
    required this.dateLabel,
    required this.category,
    required this.title,
    required this.subtitle,
    required this.time,
    required this.unread,
    required this.badgeColor,
    required this.badgeIcon,
    this.avatarBackgroundColor,
    this.avatarIcon,
    this.avatarAssetPath,
  });

  final String dateLabel;
  final _NotificationCategory category;
  final String title;
  final String subtitle;
  final String time;
  final bool unread;
  final Color badgeColor;
  final IconData badgeIcon;
  final Color? avatarBackgroundColor;
  final IconData? avatarIcon;
  final String? avatarAssetPath;
}

class _NotificationSectionData {
  const _NotificationSectionData({
    required this.dateLabel,
    required this.items,
  });

  final String dateLabel;
  final List<_NotificationItem> items;
}
